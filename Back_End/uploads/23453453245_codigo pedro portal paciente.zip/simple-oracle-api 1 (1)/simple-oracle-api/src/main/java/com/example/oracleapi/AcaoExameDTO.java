package com.example.oracleapi;

import java.util.Date;

public class AcaoExameDTO {
    public Integer nrSequencia;
    public String dsObservacao;
    public String dsAcao;
    public Date dtAtualizacao;
	public String nmUsuario;
}
